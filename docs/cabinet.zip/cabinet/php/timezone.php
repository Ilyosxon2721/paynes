<?php date_default_timezone_set("UTC");
date_default_timezone_set("Asia/Tashkent"); ?>