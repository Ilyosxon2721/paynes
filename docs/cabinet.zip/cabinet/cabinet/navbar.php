<br>
<a href="home.php"><h2 id="navbar-title"><?= $header_title; ?></h2></a>
<!-- <div class="search" id="search">
    <input type="search" placeholder="Поиск...">
</div> -->
<h3 id="user_name"><?php  echo $user_fio;?></h3>
<a id="btn-exit" class="btn btn-primary" type="button" href="exit.php " >Выйти </a>